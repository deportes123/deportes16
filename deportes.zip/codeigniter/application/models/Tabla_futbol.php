<?php

  class Tabla_futbol extends CI_Model{
    private $tabla = "futbol";

    public function __construct(){
        parent::__construct();
  }//end function__construct

    public function select_all(){
      $this->db->select('*');
      $this->db->from($this->tabla);
      $rows = $this->db->get();
      return $rows->result();
    }//end select_all

    public function select($constraints){
      $query = $this->db->get_where($this->tabla, $constraints);
        return $query->result();
    }//end select

 }//en class Tabla_futbol
 ?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beisbol extends CI_Controller {

	public function index(){
		$this->load->view('portal/beisbol');
	}//end index
}//end class

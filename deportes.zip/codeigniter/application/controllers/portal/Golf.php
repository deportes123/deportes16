<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Golf extends CI_Controller {

	public function index(){
		$this->load->view('portal/golf');
	}//end index
}//end class

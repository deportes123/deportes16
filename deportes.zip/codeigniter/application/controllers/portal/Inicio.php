<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio extends CI_Controller {

	public function __construct(){
			parent::__construct();
}//end function__construct


	public function index()	{
				//$this->load->view('portal/inicio');
				$this->crear_vista('portal/inicio',$this->cargar_datos());
		}//end index

		public function cargar_datos(){
			$datos = array();

			//datos BD
			$this->load->model('Tabla_futbol');
			$datos['deporte'] = $this->Tabla_futbol->select_all();

			//titulos
			$datos['titulo_tab'] = 'Deportes';
			$datos['titulo_seccion'] = 'Inicio';
			$datos['subtitulo_seccion'] = 'Primera vista en Codeigniter';

			//navegacion
			$datos['navegacion'] = array();

			return $datos;
		}//end funtion cargar_datos

		public function crear_vista($nombre_vista=NULL, $datos=NULL){
			$this->load->view($nombre_vista, $datos);
			//$data['contenido'] = $this->load->view($nombre_vista, $datos, TRUE);
			//$data['menu_portal'] = crear_menu_portal($this->constantes->PAGINA_HOME, TRUE);
		}
	}//end class inicio

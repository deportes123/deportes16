<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Basquetbol extends CI_Controller {

	public function index(){
		$this->load->view('portal/basquetbol');
	}//end index
}//end class

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {

	public function index($tarea_actual=0)	{

	 	switch ($tarea_actual) {
			case 0:
				redirect('portal/inicio');
				break;

			case 1:
				redirect('portal/futbol');
				break;

			case 2:
					redirect('portal/golf');
					break;

			case 3:
					redirect('portal/tenis');
					break;

			case 4:
					redirect('portal/basquetbol');
					break;

			case 5:
					redirect('portal/beisbol');
					break;

			default:
				$this->load->view('test');
				break;
		}
	}
}

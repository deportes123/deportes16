<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: #03DA82;
				}
				.navegacion{
					margin: auto;
					width: 600px;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
				.centrado{
					margin:10px auto;
					display: block;
				}
			</style>
	<body>

		<div id="container" align="center">
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br><br><br><br><br>

			<b>
		    <h1>Tenis.</h1>
			</b>
			<b>
				<h3>
					<p>
						El tenis es un deporte que requiere que los jugadores dominen<br><br>
						técnicas como son: golpes, empuñaduras, efectos, posiciones<br><br>
					  corporales y desplazamientos corporales, además de necesitar <br><br>
						resistencia física para aguantar peloteos largos o fuertes. <br><br>
						Durante el partido se utilizan muchos tipos de golpes, cada uno<br><br>
						con sus respectivas técnicas; los golpes son: el saque, la<br><br>
						derecha (forehand), el revés, el globo, la volea, el slice, la<br><br>
						dejada y el remate (smash).<br><br>
					</p>
				</h3>
			</b>
			<img  class="centrado"src="http://localhost/aplicaciones/codeigniter/imagenes/imagen6.jpg">
			<strong>
				<h2>¿Te gusta esta pagina?</h2>
			</strong>
				<p>
					<input type="radio" name="op" value="a">
					<h2>si</h2>
				</p>
				<p>
					<input type="radio" name="op" value="b">
					<h2>no</h2>
				</p>
		</body>
</html>

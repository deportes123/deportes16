<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: #4987FA;
					color: #E8F5F5;
				}
				.navegacion{
					margin: auto;
					width: 600px;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
			</style>
	<body>

		<div id="container" align="center">
		</div>
			<h1></h1>
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br>
			<b align="center">
		    <h1 color="#04108D">Futbol.</h1>
			</b>
			<h3 align="center"><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen13.jpg" width="70px" height="80"></h3>
			<table bgcolor="#FBFCFC" width="100%" border="2px" bordercolor="#BBFCFC">
				<tr>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen11.png" width="50px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen12.jpg" width="100px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen14.png" width="60px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen15.jpg" width="50px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen16.jpg" width="80px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen17.jpg" width="60px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen18.jpg" width="60px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen19.png" width="60px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen20.png" width="50px" height="80"></h3>
					</td>
					<td align="center">
						<h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen21.jpg" width="70px" height="80"></h3>
					</td>
				</tr>
			</table>
			<font color="#FFFFFF">
			<h1 align="center">Estadisticas la Liga 2020/2021.</h1>
      <table bgcolor="#FFFFFF" width="75%" border="5px" bordercolor="#1038B8" cellspacing="5"><br><br>
				<tr bgcolor="#616161">
      	 	<td align="center">
	    	  	<h3>Nombre</h3>
		    	</td>
	        <td align="center">
		        <h3>Equipo</h3>
			    </td>
					<td align="center">
		        <h3>Goles a Favor</h3>
			    </td>
		      <td align="center">
		        <h3>Partidos Jugados</h3>
			    </td>
	       	<td align="center">
		        <h3>Goles por Partido</h3>
			    </td>
				</tr>
				<tr bgcolor="#276BA0">
        	<td>
						<h3>1  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen22.jpg" width="60px" height="50">  Leonel Messi</h3>
				  </td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen24.jpg" width="60px" height="50">   FC Barcelona</h3>
					</td>
			    <td align="center">
				    <h3>19</h3>
					</td>
			    <td align="center">
				    <h3>23</h3>
					</td>
					<td align="center">
				    <h3>0.83</h3>
					</td>
				</tr>
				<tr bgcolor="#00325A">
	        <td>
				    <h3>2  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen23.jpg" width="60px" height="50">  Luis Suárez</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen18.jpg" width="60px" height="50"> Atletico de Madrid</h3>
					</td>
			    <td align="center">
				    <h3>16</h3>
					</td>
			    <td align="center">
				    <h3>21</h3>
					</td>
					<td align="center">
				    <h3>0.76</h3>
					</td>
				</tr>
				<tr bgcolor="#276BA">
	        <td>
				    <h3>3  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen26.jpg" width="60px" height="50">  Gerard Moreno</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen25.jpg" width="60px" height="50">  Villa Real CF</h3>
					</td>
			    <td align="center">
				    <h3>14</h3>
					</td>
			    <td align="center">
				    <h3>20</h3>
					</td>
					<td align="center">
				    <h3>0.70</h3>
					</td>
				</tr>
				<tr bgcolor="#00325A">
	        <td>
				    <h3>4  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen27.jpg" width="60px" height="50">  Youseef en-Nesyri</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen28.jpg" width="60px" height="50">  Sevilla FC</h3>
					</td>
			    <td align="center">
				    <h3>13</h3>
					</td>
			    <td align="center">
				    <h3>24</h3>
					</td>
					<td align="center">
				    <h3>0.54</h3>
					</td>
				</tr>
				<tr bgcolor="#276BA">
	        <td>
				    <h3>5  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen30.jpg" width="60px" height="50">  Mikel Oyazarbal</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen29.jpg" width="60px" height="50">  Real Sociedad</h3>
					</td>
			    <td align="center">
				    <h3>12</h3>
					</td>
			    <td align="center">
				    <h3>21</h3>
					</td>
					<td align="center">
				    <h3>0.57</h3>
					</td>
				</tr>
				<tr bgcolor="#00325A">
	        <td>
				    <h3>6  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen31.jpg" width="60px" height="50">  Karim Benzema</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen11.png" width="60px" height="50">  Real Mdrid</h3>
					</td>
			    <td align="center">
				    <h3>12</h3>
					</td>
			    <td align="center">
				    <h3>21</h3>
					</td>
					<td align="center">
				    <h3>0.57</h3>
					</td>
				</tr>
				<tr bgcolor="#276BA">
	        <td>
				    <h3>7  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen33.jpeg" width="60px" height="50">  José Luis Morales</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen32.png" width="60px" height="50">  Levante UD</h3>
					</td>
			    <td align="center">
				    <h3>10</h3>
					</td>
			    <td align="center">
				    <h3>25</h3>
					</td>
					<td align="center">
				    <h3>0.40</h3>
					</td>
				</tr>
				<tr bgcolor="#00325A">
	        <td>
				    <h3>8  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen34.jpeg" width="60px" height="50">  Iago Aspas</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen35.png" width="60px" height="50">  RC Celta</h3>
					</td>
			    <td align="center">
				    <h3>9</h3>
					</td>
			    <td align="center">
				    <h3>21</h3>
					</td>
					<td align="center">
				    <h3>0.43</h3>
					</td>
				</tr>
				<tr bgcolor="#276BA">
	        <td>
				    <h3>9  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen36.jpg" width="60px" height="50"> Sergio Cnales</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen37.jpg" width="60px" height="50">  Real Betis</h3>
					</td>
			    <td align="center">
				    <h3>7</h3>
					</td>
			    <td align="center">
				    <h3>19</h3>
					</td>
					<td align="center">
				    <h3>0.37</h3>
					</td>
				</tr>
				<tr bgcolor="#00325A">
	        <td>
				    <h3>10  <img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen39.png" width="60px" height="50">  Alejandro Remiro</h3>
					</td>
			    <td>
				    <h3><img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen38.jpg" width="60px" height="50">  Athletic Club</h3>
					</td>
			    <td align="center">
				    <h3>6</h3>
					</td>
			    <td align="center">
				    <h3>21</h3>
					</td>
					<td align="center">
				    <h3>0.29</h3>
					</td>
				</tr>
			</table>
		</body>
</html>

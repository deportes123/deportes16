<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: #f78f34;
				}
				.navegacion{
					margin: auto;
					width: 600px;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
				.centrado{
					margin:10px auto;
					display: block;
				}
			</style>
	<body>

		<div id="container" align="center">
		</div>
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br><br><br><br><br>

			<b align="center">
		    <h1>Beisbol.</h1>
			</b>
			<img class="centrado" src="http://localhost/aplicaciones/codeigniter/imagenes/imagen10.jpg" width="800px" height="400">
			<b>
				<h2>
					<p align="center">
						El béisbol, también llamado baseball o pelota base,
						es un deporte de equipo jugado entre dos equipos de
						nueve jugadores cada uno. Es considerado uno de los
						deportes más populares en México, Corea del Sur, Cuba,
						Estados Unidos, Curazao, Aruba, Japón, Nicaragua,
						Panamá, Puerto Rico, República Dominicana y Venezuela,
						y no tan popular pero con una cantidad importante de
						aficionados en países como Canadá, Australia, Sudáfrica,
						Colombia, China, Taiwán, Países Bajos e Italia.
						Los países considerados potencias de este deporte se
						encuentran ubicados en América y en Asia Oriental, siendo
						los continentes europeo y africano los más rezagados.
					</p>
				</h2>
			</b>
		</body>
</html>

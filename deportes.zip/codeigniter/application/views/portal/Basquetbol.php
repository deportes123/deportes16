<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: lightblue;
				}
				.navegacion{
					margin: auto;
					width: 600px;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
				.centrado{
					margin:10px auto;
					display: block;
				}
				.container-all img{
					width: 300px;
					float: left;
					margin-right: 20px;
					margin-bottom: 20;
				}
				.container-all p{
					font-size: 20px;
					font-weight: 300px;
				}
			</style>
	<body>

		<div class="container-all">
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br><br><br><br><br>

			<b align="center">
	    	<h1>Basquetbol.</h1>
			</b>
			<img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen8.jpg">
			<b>
				<h2>
					<p align="center">
						El objetivo del equipo es anotar puntos introduciendo
						un balón por la canasta, un aro a 3,05 metros sobre
						la superficie de la pista de juego del que cuelga una
						red.</p>
						<p>La puntuación por cada canasta o cesta es de dos
					  o tres puntos, dependiendo de la posición desde la que
						se efectúa el tiro a canasta, o de uno, si se trata de
						un tiro libre por una falta de un jugador contrario.
						El equipo ganador es el que obtiene el mayor número
						de puntos.</p>
						<p>El contacto con la pelota se realiza con las manos.
					  Los jugadores, también llamados baloncestistas, no
					  pueden trasladarse sujetando la pelota, sino botándola
					  contra el suelo. El equipo en posesión del balón o
					  atacante, intenta anotar puntos mediante tiros,
					  entradas a canasta o mates, mientras que el equipo
					  defensor busca impedirlo robando la pelota o
					  efectuando tapones. Cuando un tiro hacia la canasta
					  fracasa, los jugadores de ambos equipos intentan
					  atrapar el rebote.</p>
					</p>
				</h2>
			</b>
			<img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen9.jpg">
		</div>
	</body>
</html>

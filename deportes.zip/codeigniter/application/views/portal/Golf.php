<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: #34AC72;
				}
				.navegacion{
					margin: auto;
					width: 600px;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
				.centrado{
					margin:10px auto;
					display: block;
				}
			</style>
	<body>

		<div id="container" align="center">
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br><br><br><br><br>

			<b align="center">
		    <h1>Golf.</h1>
			</b>
			<img class="centrado"src="http://localhost/aplicaciones/codeigniter/imagenes/imagen4.jpg">
			<b>
				<h2>
					<p align="center">
						El golf es un deporte cuyo objetivo es introducir una bola en los hoyos que están<br><br>
						distribuidos en el campo con el menor número de golpes, utilizando para cada tipo<br><br>
						de golpe uno de entre un conjunto de palos ligeramente diferentes entre sí, ya que<br><br>
						la cabeza del palo tiene ángulos distintos, al igual que las varillas tienen<br><br>
						longitudes diferentes. A menor número de grados de inclinación, mayor longitud de<br><br>
						la varilla y, por lo tanto, más distancia.<br><br>
					</p>
				</h2>
			</b>
			<img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen5.jpg">
      <table bgcolor="#6185F6" width="75%" border="5px" bordercolor="#1038B8" cellspacing="5" align="center" ><br><br><br><br>
        <tr bgcolor="#D7EB10">
      	 	<td align="center">
	    	  	<h3>Clasificacion</h3>
		    	</td>
	        <td align="center">
		        <h3>No.Jugador</h3>
			    </td>
					<td align="center">
		        <h3>Apellido Paterno</h3>
			    </td>
		      <td align="center">
		        <h3>Apellido Materno</h3>
			    </td>
	       	<td align="center">
		        <h3>Fecha de N. Dia/Mes/Año</h3>
			    </td>
				</tr>
				<tr bgcolor="#0CD860">
        	<td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
				<tr bgcolor="#D7EB10">
	        <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
				<tr bgcolor="#0CD860">
	        <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
			</table>
		</body>
</html>

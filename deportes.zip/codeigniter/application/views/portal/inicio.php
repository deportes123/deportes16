<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Deportes</title>

	</head>
	<style type="text/css">
				body{
					font-family: Arial;
					background-color: lightblue;
				}
				.menu-fixed{
					position: fixed;
					z-index: 1000;
					top: 0;
					width: 100%;
					font-family: Arial;
					color: #F3F8F5;
				}
				.menu li{
					display: inline-block;
				}
				.menu >li > a{
					display: block;
					padding: 15px 20px;
					color: #fff;
					text-decoration: none;
				}
				.menu li a:hover{
					color: #F16001;
					transition: all .3s;
				}
				ul{
					list-style: none;
					background-color: #073751;
					padding: 15px 20px;
				}
			</style>
	<body>
		<div id="container" align="center">
			<h1>Bienvenido a mi Blog de Deportes</h1><br>
		</div>
		  <nav class="">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href=<?php echo base_url('portal/futbol');?>>Futbol</a></li>
					<li><a href=<?php echo base_url('portal/golf');?>>Golf</a></li>
					<li><a href=<?php echo base_url('portal/tenis');?>>Tenis</a></li>
					<li><a href=<?php echo base_url('portal/basquetbol');?>>Basquetbol</a></li>
					<li><a href=<?php echo base_url('portal/beisbol');?>>Beisbol</a></li>
				</ul>
			</nav><br><br><br><br><br>
			<b align="center">
		    <h1>Deportes.</h1>
			</b>
			<img src="http://localhost/aplicaciones/codeigniter/imagenes/imagen2.jpg" width="1325px" height="450">
			<b>
				<h2>
					<p align="center">
						El deporte es una actividad que el ser humano realiza principalmente con objetivos<br><br>
						aun que en algunos casos puede convertirse en la profecion de una persona si la<br><br>
						misma se dedica de manera intenciva a ella y perfeciona su tecnica y sus resultados<br><br>
						de manera permanente. El deporte es basicamente una actividad fisica que hce entrar<br><br>
						al cuerpo en funcionamiento y que lo saca de su estado de reposo frente al cual se <br><br>
						encuentra normalmente.<br><br>
					</p>
				</h2>
			</b>
			<?php
			 	foreach ($deporte as $futbol) {
					echo $futbol->id_Deporte.'-'.$futbol->Nombre_Equipo.'-'.$futbol->Clasificacion.'-'.$futbol->Goles.'-'.$futbol->Asistencias.'-'.$futbol->Tiros.'-'.$futbol->Puntos.'-'.$futbol->Derrotas.'-'.$futbol->Enpate.'<br>';
			 	}//end foreach
			 ?>
			 <br>
			 <hr>
			 <table bgcolor="#6185F" width="75%" border="5px" bordercolor="#1038B8" cellspacing="5" align="center" >
			 		<thead>
						<th>ID Deporte</th>
						<th>Nombre de Equipo</th>
						<th>Clasificacion</th>
						<th>Goles</th>
						<th>Asistencias</th>
						<th>Tiros</th>
						<th>Puntos</th>
						<th>Derrotas</th>
						<th>Enpate</th>
					</thead>

					<tbody>
						<?php
						 	foreach ($deporte as $futbol) {
								echo '<tr>';
										echo '<td>'.$futbol->id_Deporte.'</td>';
										echo '<td>'.$futbol->Nombre_Equipo.'</td>';
										echo '<td>'.$futbol->Clasificacion.'</td>';
										echo '<td>'.$futbol->Goles.'</td>';
										echo '<td>'.$futbol->Asistencias.'</td>';
										echo '<td>'.$futbol->Tiros.'</td>';
										echo '<td>'.$futbol->Puntos.'</td>';
										echo '<td>'.$futbol->Derrotas.'</td>';
										echo '<td>'.$futbol->Enpate.'</td>';
								echo '</tr>';
						 	}//end foreach

					  ?>


			<font color="#0048A5"><h2><p>Suscríbete a mi Blog de Deportes</p></h2>
			<form>
	       <section>
	        <input type="text" name="nombres" id="nombres" placeholder="Ingresa tu Nombre" /></p>
	        <input type="text" name="apellidos" id="apellidos" placeholder="Ingresa tu Apellido" /></p>
	        <input type="email" name="correo" id="correo" placeholder="Ingresa tu correo"/></p>
	        <input type="password" name="correo" id="correo" placeholder="Ingrese su Contraseña:" /></p>
			<p> Estoy deacuerdo con <a href="#">Terminos y condiciones</p>
			<input type="submit" value="Registrar">
			<p><a href="#">¿Ya tengo cuenta?</a></p>
		   </section>
	   </form>
		</body>
</html>

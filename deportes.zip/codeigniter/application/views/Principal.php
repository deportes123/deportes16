<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Bienvenido a mi codeigniter</title>

	</head>
	<style>
				body{
					font-family: Arial;
					background-color: lightblue;
				}
				.menu {
					 list-style: none;
					 padding: 0;
					 background: #092327;
					 width: 48%;
					 max-width: 1000px;
					 margin: auto;
				}
				.menu li a{
					text-decoration: none;
					color: white;
					padding: 20px;
					display: block;
				}
				.menu li{
					position: relative;
					display: inline-block;
				}
				.menu li a:hover{
					background: #BFDC09;

				}
				.submenu{
					position: absolute;
					background: #09DC73;
					width: 100%;
					display: none;
				}
				.submenu li a{
					display: block;
					padding: 15px;
					color: #f9f9f9;
					font-family: Arial;
					text-decoration: none;
				}
				.menu li:hover .submenu{
					display: block;
				}

			</style>
	<body>

		<div id="container" align="center">
			<h1>Bienvenido a mi codeigniter</h1>
		</div>
			<h1></h1>
		<p>
			<h2 align=center>Menu</h2>
		</p>
		  <nav class="navegacion">
				<ul class="menu">
					<li><a href=<?php echo base_url('portal/inicio');?>>Inicio</a></li>
					<li><a href="#">Productos</a>
						<ul class="submenu">
							<li><a href="#">Producto #1</a></li>
							<li><a href="#">Producto #2</a></li>
							<li><a href="#">Producto #3</a></li>
						</ul>
					</li>
					<li><a href="#">Servicios</a></li>
					<li><a href="#">Costos</a></li>
					<li><a href="#">Ofertas</a></li>
					<li><a href="#">Ayuda</a></li>
				</ul>
			</nav><br><br><br><br><br>

			<b align="center">
		    <h1>Autos de lujo.</h1>
			</b>
			<b>
				<h2>
					<p align="center">
						Volkswagen de México S.A de C.V, División Audi agradece tu visita nuestro sitio de internet,<br><br>
						donde encontrarás información sobre nuevos modelos, servicios, planes de financiamiento, accesorios<br><br>
				  	y promociones vigentes de vehículos nuevos de la marca Audi. Es el único sitio de confianza que es<br><br>
					  oficial de la marca Audi para territorio mexicano, por lo anterior recomendamos que en caso de<br><br>
						presentarse dudas respecto a vehículos, promociones, accesorios y/o servicios de la marca Audi se<br><br>
						 realice la consulta en las correspondientes secciones del sitio de internet.<br><br>
					</p>
				</h2>
			</b>
      <table bgcolor="#6185F6" width="75%" border="5px" bordercolor="#1038B8" cellspacing="5" align="center" ><br><br><br><br>
        <tr bgcolor="#B7C0DE">
      	 	<td align="center">
	    	  	<h3>Producto</h3>
		    	</td>
	        <td align="center">
		        <h3>N.Cliente</h3>
			    </td>
					<td align="center">
		        <h3>Apellido Paterno</h3>
			    </td>
		      <td align="center">
		        <h3>Apellido Materno</h3>
			    </td>
	       	<td align="center">
		        <h3>Fecha de N. Dia/Mes/Año</h3>
			    </td>
				</tr>
				<tr bgcolor="#ff9d80">
        	<td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
				<tr bgcolor="#ff9d80">
	        <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
				<tr bgcolor="#ff9d80">
	        <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
			    <td align="center">
				    <h3></h3>
					</td>
					<td align="center">
				    <h3></h3>
					</td>
				</tr>
			</table>
			<font color="#e50623"><h2><p>FORMULARIO</p></h2>
			<form>
	       <section>
	        <input type="text" name="nombres" id="nombres" placeholder="Ingresa tu Nombre" /></p>
	        <input type="text" name="apellidos" id="apellidos" placeholder="Ingresa tu Apellido" /></p>
	        <input type="email" name="correo" id="correo" placeholder="Ingresa tu correo"/></p>
	        <input type="password" name="correo" id="correo" placeholder="Ingrese su Contraseña:" /></p>
			<p> Estoy deacuerdo con <a href="#">Terminos y condiciones</p>
			<input type="submit" value="Registrar">
			<p><a href="#">¿Ya tengo cuenta?</a></p>
		   </section>
	   </form>
		</body>
</html>
